﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonsterHunterCompanion
{
    public class Quests
    {
        public string _type;

        public string _name;
        
        public string _quest;
        
        public int _reward;
        
        public int _fee;
        
        public string _location;
    }
}
