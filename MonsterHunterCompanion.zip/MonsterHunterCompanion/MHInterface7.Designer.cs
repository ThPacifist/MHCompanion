﻿namespace MonsterHunterCompanion
{
    partial class MHCompanion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MHCompanion));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Weapons = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.GSGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.LSGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.SnSGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.DBGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.HMGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.HHGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.LGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.GLGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.SAGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.IGGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.CBGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.LBGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.HBGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel14 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.BowGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel15 = new System.Windows.Forms.TableLayoutPanel();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.ASGridview = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.QGridview = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.MonGridview = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.ItemsGridview = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.SkiGridView = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.PArGridview = new System.Windows.Forms.DataGridView();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.PWeGridview = new System.Windows.Forms.DataGridView();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.DecGridview = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GSGridview)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LSGridview)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SnSGridview)).BeginInit();
            this.tableLayoutPanel4.SuspendLayout();
            this.tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DBGridview)).BeginInit();
            this.tableLayoutPanel5.SuspendLayout();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HMGridview)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HHGridview)).BeginInit();
            this.tableLayoutPanel7.SuspendLayout();
            this.tabPage16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LGridview)).BeginInit();
            this.tableLayoutPanel8.SuspendLayout();
            this.tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GLGridview)).BeginInit();
            this.tableLayoutPanel9.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SAGridview)).BeginInit();
            this.tableLayoutPanel10.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IGGridview)).BeginInit();
            this.tableLayoutPanel11.SuspendLayout();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CBGridview)).BeginInit();
            this.tableLayoutPanel12.SuspendLayout();
            this.tabPage21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LBGridview)).BeginInit();
            this.tableLayoutPanel13.SuspendLayout();
            this.tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HBGridview)).BeginInit();
            this.tableLayoutPanel14.SuspendLayout();
            this.tabPage25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BowGridview)).BeginInit();
            this.tableLayoutPanel15.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ASGridview)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QGridview)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MonGridview)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemsGridview)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SkiGridView)).BeginInit();
            this.tabPage8.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PArGridview)).BeginInit();
            this.tabPage24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PWeGridview)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DecGridview)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoScroll = true;
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 69F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 283F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 648F));
            this.tableLayoutPanel1.Controls.Add(this.Weapons, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label8, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label9, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label10, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label11, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label12, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label13, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label14, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.label15, 2, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(991, 660);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.TableLayoutPanel1_Paint);
            // 
            // Weapons
            // 
            this.Weapons.AutoSize = true;
            this.Weapons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Weapons.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Weapons.Location = new System.Drawing.Point(75, 2);
            this.Weapons.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Weapons.Name = "Weapons";
            this.Weapons.Size = new System.Drawing.Size(279, 119);
            this.Weapons.TabIndex = 6;
            this.Weapons.Text = "Weapons";
            this.Weapons.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Weapons.Click += new System.EventHandler(this.Weapons_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 123);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(279, 119);
            this.label1.TabIndex = 7;
            this.label1.Text = "Armor Sets";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(75, 244);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(279, 119);
            this.label2.TabIndex = 8;
            this.label2.Text = "Quests";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(75, 365);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(279, 119);
            this.label3.TabIndex = 9;
            this.label3.Text = "Monsters";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(75, 486);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 119);
            this.label4.TabIndex = 10;
            this.label4.Text = "Items";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(75, 607);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(279, 119);
            this.label5.TabIndex = 11;
            this.label5.Text = "Skills";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(75, 728);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(279, 119);
            this.label6.TabIndex = 12;
            this.label6.Text = "Palicoes";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(75, 849);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(279, 123);
            this.label7.TabIndex = 13;
            this.label7.Text = "Decorations";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(360, 63);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(760, 58);
            this.label8.TabIndex = 17;
            this.label8.Text = "This contains all of the weapons that are obtainable in Monster Hunter.\r\n\r\n";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label9.Location = new System.Drawing.Point(360, 184);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(763, 58);
            this.label9.TabIndex = 18;
            this.label9.Text = "This contain all of the armor sets that are obtainable in Monster Hunter.\r\n\r\n";
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label10.Location = new System.Drawing.Point(360, 305);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(529, 58);
            this.label10.TabIndex = 19;
            this.label10.Text = "This contains all of the quests in Monster Hunter.\r\n\r\n";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label11.Location = new System.Drawing.Point(360, 426);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(811, 58);
            this.label11.TabIndex = 20;
            this.label11.Text = "This contains all of the information on all of the monsters in Monster Hunter.\r\n\r" +
    "\n";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label12.Location = new System.Drawing.Point(360, 547);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(516, 58);
            this.label12.TabIndex = 21;
            this.label12.Text = "This contains all of the items in Monster Hunter.\r\n\r\n";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label13.Location = new System.Drawing.Point(360, 668);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(512, 58);
            this.label13.TabIndex = 22;
            this.label13.Text = "This contains all of the skills in Monster Hunter.\r\n\r\n";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label14.Location = new System.Drawing.Point(360, 789);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(813, 58);
            this.label14.TabIndex = 23;
            this.label14.Text = "This contains all of the weapons and armor for Palicoes for Monster Hunter.\r\n\r\n";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label15.Location = new System.Drawing.Point(360, 914);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(545, 58);
            this.label15.TabIndex = 24;
            this.label15.Text = "This contains all of decorations in Monster Hunter.\r\n\r\n";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1003, 690);
            this.tabControl1.TabIndex = 25;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage1.Size = new System.Drawing.Size(995, 664);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Home";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage2.Size = new System.Drawing.Size(995, 664);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Weapons";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl2.Controls.Add(this.tabPage10);
            this.tabControl2.Controls.Add(this.tabPage11);
            this.tabControl2.Controls.Add(this.tabPage12);
            this.tabControl2.Controls.Add(this.tabPage13);
            this.tabControl2.Controls.Add(this.tabPage14);
            this.tabControl2.Controls.Add(this.tabPage15);
            this.tabControl2.Controls.Add(this.tabPage16);
            this.tabControl2.Controls.Add(this.tabPage17);
            this.tabControl2.Controls.Add(this.tabPage18);
            this.tabControl2.Controls.Add(this.tabPage19);
            this.tabControl2.Controls.Add(this.tabPage20);
            this.tabControl2.Controls.Add(this.tabPage21);
            this.tabControl2.Controls.Add(this.tabPage22);
            this.tabControl2.Controls.Add(this.tabPage25);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(2, 2);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControl2.Multiline = true;
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(991, 660);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage10.Controls.Add(this.GSGridview);
            this.tabPage10.Controls.Add(this.tableLayoutPanel2);
            this.tabPage10.Location = new System.Drawing.Point(42, 4);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage10.Size = new System.Drawing.Size(945, 652);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "Greatsword";
            // 
            // GSGridview
            // 
            this.GSGridview.AllowUserToAddRows = false;
            this.GSGridview.AllowUserToDeleteRows = false;
            this.GSGridview.AllowUserToResizeColumns = false;
            this.GSGridview.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GSGridview.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.GSGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GSGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GSGridview.Location = new System.Drawing.Point(2, 153);
            this.GSGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GSGridview.Name = "GSGridview";
            this.GSGridview.RowTemplate.Height = 28;
            this.GSGridview.Size = new System.Drawing.Size(941, 497);
            this.GSGridview.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel2.Controls.Add(this.label16, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label17, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(941, 151);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(2, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(328, 75);
            this.label16.TabIndex = 1;
            this.label16.Text = "Greatsword";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.tableLayoutPanel2.SetColumnSpan(this.label17, 2);
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(2, 75);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(933, 76);
            this.label17.TabIndex = 2;
            this.label17.Text = resources.GetString("label17.Text");
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage11.Controls.Add(this.LSGridview);
            this.tabPage11.Controls.Add(this.tableLayoutPanel3);
            this.tabPage11.Location = new System.Drawing.Point(42, 4);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage11.Size = new System.Drawing.Size(945, 652);
            this.tabPage11.TabIndex = 1;
            this.tabPage11.Text = "Longsword";
            // 
            // LSGridview
            // 
            this.LSGridview.AllowUserToAddRows = false;
            this.LSGridview.AllowUserToDeleteRows = false;
            this.LSGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LSGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LSGridview.Location = new System.Drawing.Point(2, 151);
            this.LSGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LSGridview.Name = "LSGridview";
            this.LSGridview.ReadOnly = true;
            this.LSGridview.RowTemplate.Height = 28;
            this.LSGridview.Size = new System.Drawing.Size(941, 499);
            this.LSGridview.TabIndex = 2;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel3.Controls.Add(this.label18, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label19, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(941, 149);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(2, 0);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(328, 74);
            this.label18.TabIndex = 1;
            this.label18.Text = "Longsword";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.tableLayoutPanel3.SetColumnSpan(this.label19, 2);
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(2, 74);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(937, 75);
            this.label19.TabIndex = 2;
            this.label19.Text = resources.GetString("label19.Text");
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage12.Controls.Add(this.SnSGridview);
            this.tabPage12.Controls.Add(this.tableLayoutPanel4);
            this.tabPage12.Location = new System.Drawing.Point(23, 4);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage12.Size = new System.Drawing.Size(966, 656);
            this.tabPage12.TabIndex = 2;
            this.tabPage12.Text = "Sword and Shield";
            this.tabPage12.Click += new System.EventHandler(this.tabPage12_Click);
            // 
            // SnSGridview
            // 
            this.SnSGridview.AllowUserToAddRows = false;
            this.SnSGridview.AllowUserToDeleteRows = false;
            this.SnSGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SnSGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SnSGridview.Location = new System.Drawing.Point(2, 153);
            this.SnSGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SnSGridview.Name = "SnSGridview";
            this.SnSGridview.ReadOnly = true;
            this.SnSGridview.RowTemplate.Height = 28;
            this.SnSGridview.Size = new System.Drawing.Size(962, 501);
            this.SnSGridview.TabIndex = 2;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.02521F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.97479F));
            this.tableLayoutPanel4.Controls.Add(this.label20, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label21, 0, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(2, 0);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(361, 75);
            this.label20.TabIndex = 1;
            this.label20.Text = "Sword and Shield";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.tableLayoutPanel4.SetColumnSpan(this.label21, 2);
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(2, 75);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(958, 76);
            this.label21.TabIndex = 2;
            this.label21.Text = resources.GetString("label21.Text");
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage13.Controls.Add(this.DBGridview);
            this.tabPage13.Controls.Add(this.tableLayoutPanel5);
            this.tabPage13.Location = new System.Drawing.Point(23, 4);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage13.Size = new System.Drawing.Size(966, 656);
            this.tabPage13.TabIndex = 3;
            this.tabPage13.Text = "Dual Blades";
            // 
            // DBGridview
            // 
            this.DBGridview.AllowUserToAddRows = false;
            this.DBGridview.AllowUserToDeleteRows = false;
            this.DBGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DBGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DBGridview.Location = new System.Drawing.Point(2, 153);
            this.DBGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DBGridview.Name = "DBGridview";
            this.DBGridview.ReadOnly = true;
            this.DBGridview.RowTemplate.Height = 28;
            this.DBGridview.Size = new System.Drawing.Size(962, 501);
            this.DBGridview.TabIndex = 2;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel5.Controls.Add(this.label22, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label23, 0, 1);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(2, 0);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(335, 75);
            this.label22.TabIndex = 1;
            this.label22.Text = "Dual Blades";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.label23, 2);
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(2, 75);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(958, 76);
            this.label23.TabIndex = 2;
            this.label23.Text = resources.GetString("label23.Text");
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage14.Controls.Add(this.HMGridview);
            this.tabPage14.Controls.Add(this.tableLayoutPanel6);
            this.tabPage14.Location = new System.Drawing.Point(23, 4);
            this.tabPage14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage14.Size = new System.Drawing.Size(966, 656);
            this.tabPage14.TabIndex = 4;
            this.tabPage14.Text = "Hammer";
            // 
            // HMGridview
            // 
            this.HMGridview.AllowUserToAddRows = false;
            this.HMGridview.AllowUserToDeleteRows = false;
            this.HMGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HMGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HMGridview.Location = new System.Drawing.Point(2, 153);
            this.HMGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.HMGridview.Name = "HMGridview";
            this.HMGridview.ReadOnly = true;
            this.HMGridview.RowTemplate.Height = 28;
            this.HMGridview.Size = new System.Drawing.Size(962, 501);
            this.HMGridview.TabIndex = 2;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel6.Controls.Add(this.label24, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label25, 0, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(2, 0);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(335, 75);
            this.label24.TabIndex = 1;
            this.label24.Text = "Hammer";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.tableLayoutPanel6.SetColumnSpan(this.label25, 2);
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(2, 75);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(958, 76);
            this.label25.TabIndex = 2;
            this.label25.Text = resources.GetString("label25.Text");
            // 
            // tabPage15
            // 
            this.tabPage15.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage15.Controls.Add(this.HHGridview);
            this.tabPage15.Controls.Add(this.tableLayoutPanel7);
            this.tabPage15.Location = new System.Drawing.Point(23, 4);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage15.Size = new System.Drawing.Size(966, 656);
            this.tabPage15.TabIndex = 5;
            this.tabPage15.Text = "Hunting Horn";
            // 
            // HHGridview
            // 
            this.HHGridview.AllowUserToAddRows = false;
            this.HHGridview.AllowUserToDeleteRows = false;
            this.HHGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HHGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HHGridview.Location = new System.Drawing.Point(2, 153);
            this.HHGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.HHGridview.Name = "HHGridview";
            this.HHGridview.ReadOnly = true;
            this.HHGridview.RowTemplate.Height = 28;
            this.HHGridview.Size = new System.Drawing.Size(962, 501);
            this.HHGridview.TabIndex = 2;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 2;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel7.Controls.Add(this.label26, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label27, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(2, 0);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(335, 75);
            this.label26.TabIndex = 1;
            this.label26.Text = "Hunting Horn";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.tableLayoutPanel7.SetColumnSpan(this.label27, 2);
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(2, 75);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(958, 76);
            this.label27.TabIndex = 2;
            this.label27.Text = resources.GetString("label27.Text");
            // 
            // tabPage16
            // 
            this.tabPage16.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage16.Controls.Add(this.LGridview);
            this.tabPage16.Controls.Add(this.tableLayoutPanel8);
            this.tabPage16.Location = new System.Drawing.Point(23, 4);
            this.tabPage16.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage16.Size = new System.Drawing.Size(966, 656);
            this.tabPage16.TabIndex = 6;
            this.tabPage16.Text = "Lance";
            // 
            // LGridview
            // 
            this.LGridview.AllowUserToAddRows = false;
            this.LGridview.AllowUserToDeleteRows = false;
            this.LGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LGridview.Location = new System.Drawing.Point(2, 153);
            this.LGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LGridview.Name = "LGridview";
            this.LGridview.ReadOnly = true;
            this.LGridview.RowTemplate.Height = 28;
            this.LGridview.Size = new System.Drawing.Size(962, 501);
            this.LGridview.TabIndex = 2;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel8.Controls.Add(this.label28, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.label29, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // label28
            // 
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(2, 0);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(335, 75);
            this.label28.TabIndex = 1;
            this.label28.Text = "Lance";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.tableLayoutPanel8.SetColumnSpan(this.label29, 2);
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(2, 75);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(958, 76);
            this.label29.TabIndex = 2;
            this.label29.Text = resources.GetString("label29.Text");
            // 
            // tabPage17
            // 
            this.tabPage17.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage17.Controls.Add(this.GLGridview);
            this.tabPage17.Controls.Add(this.tableLayoutPanel9);
            this.tabPage17.Location = new System.Drawing.Point(23, 4);
            this.tabPage17.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage17.Size = new System.Drawing.Size(966, 656);
            this.tabPage17.TabIndex = 7;
            this.tabPage17.Text = "Gunlance";
            // 
            // GLGridview
            // 
            this.GLGridview.AllowUserToAddRows = false;
            this.GLGridview.AllowUserToDeleteRows = false;
            this.GLGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GLGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GLGridview.Location = new System.Drawing.Point(2, 153);
            this.GLGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.GLGridview.Name = "GLGridview";
            this.GLGridview.ReadOnly = true;
            this.GLGridview.RowTemplate.Height = 28;
            this.GLGridview.Size = new System.Drawing.Size(962, 501);
            this.GLGridview.TabIndex = 2;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 2;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel9.Controls.Add(this.label30, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.label31, 0, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(2, 0);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(335, 75);
            this.label30.TabIndex = 1;
            this.label30.Text = "Gunlance";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.tableLayoutPanel9.SetColumnSpan(this.label31, 2);
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(2, 75);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(958, 76);
            this.label31.TabIndex = 2;
            this.label31.Text = resources.GetString("label31.Text");
            // 
            // tabPage18
            // 
            this.tabPage18.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage18.Controls.Add(this.SAGridview);
            this.tabPage18.Controls.Add(this.tableLayoutPanel10);
            this.tabPage18.Location = new System.Drawing.Point(23, 4);
            this.tabPage18.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage18.Size = new System.Drawing.Size(966, 656);
            this.tabPage18.TabIndex = 8;
            this.tabPage18.Text = "Switch Axe";
            // 
            // SAGridview
            // 
            this.SAGridview.AllowUserToAddRows = false;
            this.SAGridview.AllowUserToDeleteRows = false;
            this.SAGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SAGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SAGridview.Location = new System.Drawing.Point(2, 153);
            this.SAGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SAGridview.Name = "SAGridview";
            this.SAGridview.ReadOnly = true;
            this.SAGridview.RowTemplate.Height = 28;
            this.SAGridview.Size = new System.Drawing.Size(962, 501);
            this.SAGridview.TabIndex = 2;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel10.Controls.Add(this.label32, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.label33, 0, 1);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel10.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 2;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel10.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(2, 0);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(335, 75);
            this.label32.TabIndex = 1;
            this.label32.Text = "SwitchAxe";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.tableLayoutPanel10.SetColumnSpan(this.label33, 2);
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(2, 75);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(958, 76);
            this.label33.TabIndex = 2;
            this.label33.Text = resources.GetString("label33.Text");
            // 
            // tabPage19
            // 
            this.tabPage19.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage19.Controls.Add(this.IGGridview);
            this.tabPage19.Controls.Add(this.tableLayoutPanel11);
            this.tabPage19.Location = new System.Drawing.Point(23, 4);
            this.tabPage19.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage19.Size = new System.Drawing.Size(966, 656);
            this.tabPage19.TabIndex = 9;
            this.tabPage19.Text = "Insect Glaive";
            // 
            // IGGridview
            // 
            this.IGGridview.AllowUserToAddRows = false;
            this.IGGridview.AllowUserToDeleteRows = false;
            this.IGGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.IGGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IGGridview.Location = new System.Drawing.Point(2, 153);
            this.IGGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.IGGridview.Name = "IGGridview";
            this.IGGridview.ReadOnly = true;
            this.IGGridview.RowTemplate.Height = 28;
            this.IGGridview.Size = new System.Drawing.Size(962, 501);
            this.IGGridview.TabIndex = 2;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 2;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel11.Controls.Add(this.label34, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.label35, 0, 1);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel11.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 2;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel11.TabIndex = 1;
            // 
            // label34
            // 
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(2, 0);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(335, 75);
            this.label34.TabIndex = 1;
            this.label34.Text = "Insect Glaive";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.tableLayoutPanel11.SetColumnSpan(this.label35, 2);
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(2, 75);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(958, 76);
            this.label35.TabIndex = 2;
            this.label35.Text = resources.GetString("label35.Text");
            // 
            // tabPage20
            // 
            this.tabPage20.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage20.Controls.Add(this.CBGridview);
            this.tabPage20.Controls.Add(this.tableLayoutPanel12);
            this.tabPage20.Location = new System.Drawing.Point(23, 4);
            this.tabPage20.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage20.Size = new System.Drawing.Size(966, 656);
            this.tabPage20.TabIndex = 10;
            this.tabPage20.Text = "Charge Blade";
            // 
            // CBGridview
            // 
            this.CBGridview.AllowUserToAddRows = false;
            this.CBGridview.AllowUserToDeleteRows = false;
            this.CBGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CBGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CBGridview.Location = new System.Drawing.Point(2, 153);
            this.CBGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CBGridview.Name = "CBGridview";
            this.CBGridview.ReadOnly = true;
            this.CBGridview.RowTemplate.Height = 28;
            this.CBGridview.Size = new System.Drawing.Size(962, 501);
            this.CBGridview.TabIndex = 2;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 2;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel12.Controls.Add(this.label36, 0, 0);
            this.tableLayoutPanel12.Controls.Add(this.label37, 0, 1);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel12.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 2;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel12.TabIndex = 1;
            // 
            // label36
            // 
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(2, 0);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(335, 75);
            this.label36.TabIndex = 1;
            this.label36.Text = "Charge Blade";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.tableLayoutPanel12.SetColumnSpan(this.label37, 2);
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(2, 75);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(958, 76);
            this.label37.TabIndex = 2;
            this.label37.Text = resources.GetString("label37.Text");
            // 
            // tabPage21
            // 
            this.tabPage21.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage21.Controls.Add(this.LBGridview);
            this.tabPage21.Controls.Add(this.tableLayoutPanel13);
            this.tabPage21.Location = new System.Drawing.Point(23, 4);
            this.tabPage21.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage21.Size = new System.Drawing.Size(966, 656);
            this.tabPage21.TabIndex = 11;
            this.tabPage21.Text = "Light Bowgun";
            // 
            // LBGridview
            // 
            this.LBGridview.AllowUserToAddRows = false;
            this.LBGridview.AllowUserToDeleteRows = false;
            this.LBGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LBGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LBGridview.Location = new System.Drawing.Point(2, 153);
            this.LBGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LBGridview.Name = "LBGridview";
            this.LBGridview.ReadOnly = true;
            this.LBGridview.RowTemplate.Height = 28;
            this.LBGridview.Size = new System.Drawing.Size(962, 501);
            this.LBGridview.TabIndex = 2;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 2;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel13.Controls.Add(this.label38, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.label39, 0, 1);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 2;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel13.TabIndex = 1;
            // 
            // label38
            // 
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(2, 0);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(335, 75);
            this.label38.TabIndex = 1;
            this.label38.Text = "Light Bowgun";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.tableLayoutPanel13.SetColumnSpan(this.label39, 2);
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(2, 75);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(958, 76);
            this.label39.TabIndex = 2;
            this.label39.Text = resources.GetString("label39.Text");
            // 
            // tabPage22
            // 
            this.tabPage22.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage22.Controls.Add(this.HBGridview);
            this.tabPage22.Controls.Add(this.tableLayoutPanel14);
            this.tabPage22.Location = new System.Drawing.Point(23, 4);
            this.tabPage22.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage22.Size = new System.Drawing.Size(966, 656);
            this.tabPage22.TabIndex = 12;
            this.tabPage22.Text = "Heavy Bowgun";
            // 
            // HBGridview
            // 
            this.HBGridview.AllowUserToAddRows = false;
            this.HBGridview.AllowUserToDeleteRows = false;
            this.HBGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HBGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.HBGridview.Location = new System.Drawing.Point(2, 153);
            this.HBGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.HBGridview.Name = "HBGridview";
            this.HBGridview.ReadOnly = true;
            this.HBGridview.RowTemplate.Height = 28;
            this.HBGridview.Size = new System.Drawing.Size(962, 501);
            this.HBGridview.TabIndex = 2;
            // 
            // tableLayoutPanel14
            // 
            this.tableLayoutPanel14.ColumnCount = 2;
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel14.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel14.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel14.Controls.Add(this.label41, 0, 1);
            this.tableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel14.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel14.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel14.Name = "tableLayoutPanel14";
            this.tableLayoutPanel14.RowCount = 2;
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel14.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel14.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(2, 0);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(335, 75);
            this.label40.TabIndex = 1;
            this.label40.Text = "Heavy Bowgun";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.tableLayoutPanel14.SetColumnSpan(this.label41, 2);
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(2, 75);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(958, 76);
            this.label41.TabIndex = 2;
            this.label41.Text = resources.GetString("label41.Text");
            // 
            // tabPage25
            // 
            this.tabPage25.BackColor = System.Drawing.Color.LightSkyBlue;
            this.tabPage25.Controls.Add(this.BowGridview);
            this.tabPage25.Controls.Add(this.tableLayoutPanel15);
            this.tabPage25.Location = new System.Drawing.Point(23, 4);
            this.tabPage25.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage25.Size = new System.Drawing.Size(966, 656);
            this.tabPage25.TabIndex = 13;
            this.tabPage25.Text = "Bow";
            // 
            // BowGridview
            // 
            this.BowGridview.AllowUserToAddRows = false;
            this.BowGridview.AllowUserToDeleteRows = false;
            this.BowGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BowGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BowGridview.Location = new System.Drawing.Point(2, 153);
            this.BowGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BowGridview.Name = "BowGridview";
            this.BowGridview.ReadOnly = true;
            this.BowGridview.RowTemplate.Height = 28;
            this.BowGridview.Size = new System.Drawing.Size(962, 501);
            this.BowGridview.TabIndex = 2;
            // 
            // tableLayoutPanel15
            // 
            this.tableLayoutPanel15.ColumnCount = 2;
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 35.29412F));
            this.tableLayoutPanel15.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 64.70588F));
            this.tableLayoutPanel15.Controls.Add(this.label42, 0, 0);
            this.tableLayoutPanel15.Controls.Add(this.label43, 0, 1);
            this.tableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel15.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel15.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel15.Name = "tableLayoutPanel15";
            this.tableLayoutPanel15.RowCount = 2;
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel15.Size = new System.Drawing.Size(962, 151);
            this.tableLayoutPanel15.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(2, 0);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(335, 75);
            this.label42.TabIndex = 1;
            this.label42.Text = "Bow";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.tableLayoutPanel15.SetColumnSpan(this.label43, 2);
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(2, 75);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(954, 76);
            this.label43.TabIndex = 2;
            this.label43.Text = resources.GetString("label43.Text");
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.ASGridview);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage3.Size = new System.Drawing.Size(995, 664);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Armor Sets";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // ASGridview
            // 
            this.ASGridview.AllowUserToAddRows = false;
            this.ASGridview.AllowUserToDeleteRows = false;
            this.ASGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ASGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ASGridview.Location = new System.Drawing.Point(2, 2);
            this.ASGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ASGridview.Name = "ASGridview";
            this.ASGridview.ReadOnly = true;
            this.ASGridview.RowTemplate.Height = 28;
            this.ASGridview.Size = new System.Drawing.Size(991, 660);
            this.ASGridview.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.QGridview);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage4.Size = new System.Drawing.Size(995, 664);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Quests";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // QGridview
            // 
            this.QGridview.AllowUserToAddRows = false;
            this.QGridview.AllowUserToDeleteRows = false;
            this.QGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.QGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QGridview.Location = new System.Drawing.Point(2, 2);
            this.QGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.QGridview.Name = "QGridview";
            this.QGridview.ReadOnly = true;
            this.QGridview.RowTemplate.Height = 28;
            this.QGridview.Size = new System.Drawing.Size(991, 660);
            this.QGridview.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.MonGridview);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage5.Size = new System.Drawing.Size(995, 664);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Monsters";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // MonGridview
            // 
            this.MonGridview.AllowUserToAddRows = false;
            this.MonGridview.AllowUserToDeleteRows = false;
            this.MonGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MonGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MonGridview.Location = new System.Drawing.Point(2, 2);
            this.MonGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MonGridview.Name = "MonGridview";
            this.MonGridview.ReadOnly = true;
            this.MonGridview.RowTemplate.Height = 28;
            this.MonGridview.Size = new System.Drawing.Size(991, 660);
            this.MonGridview.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.ItemsGridview);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage6.Size = new System.Drawing.Size(995, 664);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Items";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // ItemsGridview
            // 
            this.ItemsGridview.AllowUserToAddRows = false;
            this.ItemsGridview.AllowUserToDeleteRows = false;
            this.ItemsGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ItemsGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ItemsGridview.Location = new System.Drawing.Point(2, 2);
            this.ItemsGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ItemsGridview.Name = "ItemsGridview";
            this.ItemsGridview.ReadOnly = true;
            this.ItemsGridview.RowTemplate.Height = 28;
            this.ItemsGridview.Size = new System.Drawing.Size(991, 660);
            this.ItemsGridview.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.SkiGridView);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage7.Size = new System.Drawing.Size(995, 664);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Skills";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // SkiGridView
            // 
            this.SkiGridView.AllowUserToAddRows = false;
            this.SkiGridView.AllowUserToDeleteRows = false;
            this.SkiGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SkiGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SkiGridView.Location = new System.Drawing.Point(2, 2);
            this.SkiGridView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SkiGridView.Name = "SkiGridView";
            this.SkiGridView.ReadOnly = true;
            this.SkiGridView.RowTemplate.Height = 28;
            this.SkiGridView.Size = new System.Drawing.Size(991, 660);
            this.SkiGridView.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.tabControl3);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage8.Size = new System.Drawing.Size(995, 664);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Palicoes";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage23);
            this.tabControl3.Controls.Add(this.tabPage24);
            this.tabControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl3.Location = new System.Drawing.Point(2, 2);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(991, 660);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage23
            // 
            this.tabPage23.AutoScroll = true;
            this.tabPage23.Controls.Add(this.PArGridview);
            this.tabPage23.Location = new System.Drawing.Point(4, 22);
            this.tabPage23.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage23.Size = new System.Drawing.Size(983, 634);
            this.tabPage23.TabIndex = 0;
            this.tabPage23.Text = "Armor";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // PArGridview
            // 
            this.PArGridview.AllowUserToAddRows = false;
            this.PArGridview.AllowUserToDeleteRows = false;
            this.PArGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PArGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PArGridview.Location = new System.Drawing.Point(2, 2);
            this.PArGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PArGridview.Name = "PArGridview";
            this.PArGridview.ReadOnly = true;
            this.PArGridview.RowTemplate.Height = 28;
            this.PArGridview.Size = new System.Drawing.Size(979, 630);
            this.PArGridview.TabIndex = 0;
            // 
            // tabPage24
            // 
            this.tabPage24.AutoScroll = true;
            this.tabPage24.Controls.Add(this.PWeGridview);
            this.tabPage24.Location = new System.Drawing.Point(4, 22);
            this.tabPage24.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage24.Size = new System.Drawing.Size(985, 638);
            this.tabPage24.TabIndex = 1;
            this.tabPage24.Text = "Weapons";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // PWeGridview
            // 
            this.PWeGridview.AllowUserToAddRows = false;
            this.PWeGridview.AllowUserToDeleteRows = false;
            this.PWeGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PWeGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PWeGridview.Location = new System.Drawing.Point(2, 2);
            this.PWeGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PWeGridview.Name = "PWeGridview";
            this.PWeGridview.ReadOnly = true;
            this.PWeGridview.RowTemplate.Height = 28;
            this.PWeGridview.Size = new System.Drawing.Size(981, 634);
            this.PWeGridview.TabIndex = 0;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.DecGridview);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage9.Size = new System.Drawing.Size(995, 664);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Decorations";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // DecGridview
            // 
            this.DecGridview.AllowUserToAddRows = false;
            this.DecGridview.AllowUserToDeleteRows = false;
            this.DecGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DecGridview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DecGridview.Location = new System.Drawing.Point(2, 2);
            this.DecGridview.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DecGridview.Name = "DecGridview";
            this.DecGridview.ReadOnly = true;
            this.DecGridview.RowTemplate.Height = 28;
            this.DecGridview.Size = new System.Drawing.Size(991, 660);
            this.DecGridview.TabIndex = 0;
            // 
            // MHCompanion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1003, 690);
            this.Controls.Add(this.tabControl1);
            this.Name = "MHCompanion";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MHCompanion_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GSGridview)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LSGridview)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SnSGridview)).EndInit();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DBGridview)).EndInit();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HMGridview)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HHGridview)).EndInit();
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LGridview)).EndInit();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GLGridview)).EndInit();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SAGridview)).EndInit();
            this.tableLayoutPanel10.ResumeLayout(false);
            this.tableLayoutPanel10.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.IGGridview)).EndInit();
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CBGridview)).EndInit();
            this.tableLayoutPanel12.ResumeLayout(false);
            this.tableLayoutPanel12.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LBGridview)).EndInit();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HBGridview)).EndInit();
            this.tableLayoutPanel14.ResumeLayout(false);
            this.tableLayoutPanel14.PerformLayout();
            this.tabPage25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BowGridview)).EndInit();
            this.tableLayoutPanel15.ResumeLayout(false);
            this.tableLayoutPanel15.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ASGridview)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.QGridview)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MonGridview)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ItemsGridview)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SkiGridView)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PArGridview)).EndInit();
            this.tabPage24.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PWeGridview)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DecGridview)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label Weapons;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel14;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.DataGridView GSGridview;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.DataGridView LSGridview;
        private System.Windows.Forms.DataGridView SnSGridview;
        private System.Windows.Forms.DataGridView DBGridview;
        private System.Windows.Forms.DataGridView HMGridview;
        private System.Windows.Forms.DataGridView HHGridview;
        private System.Windows.Forms.DataGridView LGridview;
        private System.Windows.Forms.DataGridView GLGridview;
        private System.Windows.Forms.DataGridView SAGridview;
        private System.Windows.Forms.DataGridView IGGridview;
        private System.Windows.Forms.DataGridView CBGridview;
        private System.Windows.Forms.DataGridView LBGridview;
        private System.Windows.Forms.DataGridView HBGridview;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.DataGridView BowGridview;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel15;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DataGridView ASGridview;
        private System.Windows.Forms.DataGridView QGridview;
        private System.Windows.Forms.DataGridView MonGridview;
        private System.Windows.Forms.DataGridView ItemsGridview;
        private System.Windows.Forms.DataGridView SkiGridView;
        private System.Windows.Forms.DataGridView PArGridview;
        private System.Windows.Forms.DataGridView PWeGridview;
        private System.Windows.Forms.DataGridView DecGridview;
    }
}

