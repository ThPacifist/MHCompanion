﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonsterHunterCompanion
{
    public class Monsters
    {
        public string _name { get; set; }

        public string[] _ailments;

        public string[] _habitats;

        public string[] _weaknesses;

        public string[] _lowItems;

        public string[] _highItems;
        
        public string[] _Gitems;
    }
}
