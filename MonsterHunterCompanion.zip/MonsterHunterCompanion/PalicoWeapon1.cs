﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonsterHunterCompanion
{
    public class PalicoWeapon
    {
        public int _sharpness;

        public int _meleeAtk;

        public int _rangedAtk;

        public int _affinity;

        public int _specialAttack;

        public string _wType;

        public string _wBalance;
    }
}
